
import threading, subprocess, os, sys, time
APP_DIR = os.path.dirname(__file__)
ULTROID_DIR = os.path.join(APP_DIR, "ultroid")
LOG = os.path.join(APP_DIR, "ultroid.log")
_proc = None
_lock = threading.Lock()

def _log(s):
    with open(LOG,"a",encoding="utf-8") as f:
        f.write(time.strftime('%Y-%m-%d %H:%M:%S') + " " + s + "\n")
    print(s,flush=True)

def read_logs():
    if os.path.exists(LOG):
        return open(LOG,'r',encoding='utf-8').read()[-15000:]
    return ""

def start_bot_async():
    threading.Thread(target=start_bot, daemon=True).start()

def start_bot():
    global _proc
    with _lock:
        if _proc:
            _log("[runner] already running")
            return
        if not os.path.exists(ULTROID_DIR):
            _log("[runner] ERROR: ultroid folder not found. Copy Ultroid repo into android/app/src/main/python/ultroid/")
            return
        envfile = os.path.join(APP_DIR, ".env")
        env = os.environ.copy()
        if os.path.exists(envfile):
            for l in open(envfile,'r',encoding='utf-8').read().splitlines():
                if '=' in l:
                    k,v = l.split('=',1); env[k]=v
        cmd = [sys.executable, "-m", "pyUltroid"]
        _log("[runner] starting pyUltroid...")
        try:
            _proc = subprocess.Popen(cmd, cwd=ULTROID_DIR, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, text=True, bufsize=1)
        except Exception as e:
            _log("[runner] start failed: "+str(e)); _proc=None; return
        for line in _proc.stdout:
            _log(line.rstrip())
        _proc.wait(); _log("[runner] exited with "+str(_proc.returncode)); _proc=None

def stop_bot():
    global _proc
    with _lock:
        if _proc:
            try:
                _proc.terminate(); _log("[runner] terminate sent")
            except Exception as e:
                _log("[runner] stop error: "+str(e))
            _proc=None
        else:
            _log("[runner] not running")
