
import subprocess, shlex, os, sys, time

def run_shell_sync(cmd):
    try:
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=os.path.dirname(__file__))
        out = p.communicate()[0]
        return out
    except Exception as e:
        return str(e)
