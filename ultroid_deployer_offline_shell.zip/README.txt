
Ultroid Deployer (Offline scaffold with built-in Shell)
======================================================
This project is a Flutter + Chaquopy scaffold that provides:
- UI to fill .env
- Start/Stop buttons to run pyUltroid from a bundled ultroid/ folder
- Integrated shell: run pip install and other commands from inside the app
- "Fix Dependencies" action (runs pip install -r requirements.txt)

IMPORTANT: To make the app fully offline, COPY your full Ultroid repository into:
  android/app/src/main/python/ultroid/

Then build with Android Studio + Chaquopy (or Flutter build on desktop).

Files included:
- lib/main.dart (UI + shell)
- android/.../python/runner.py (runner + logs)
- android/.../python/term_shell.py (executes shell commands)
- build.sh helper (desktop)
