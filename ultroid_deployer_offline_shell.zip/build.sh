
#!/usr/bin/env bash
echo "Helper: If you have Flutter on desktop, run this to build:"
if command -v flutter >/dev/null 2>&1; then
  flutter pub get
  flutter build apk --release
  echo "APK built: build/app/outputs/flutter-apk/app-release.apk"
else
  echo "Install Flutter / open in Android Studio to build APK."
fi
