
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import 'package:flutter/services.dart';

void main() => runApp(const UltroidApp());

class AppState extends ChangeNotifier {
  String logs = '';
  bool running = false;
  List<String> history = [];
  void append(String s){ logs = '${DateTime.now().toIso8601String()} $s\n' + logs; notifyListeners(); }
  void setRunning(bool v){ running=v; notifyListeners(); }
  void addHistory(String cmd){ history.insert(0, cmd); if(history.length>20) history=history.sublist(0,20); notifyListeners(); }
  void clear(){ logs=''; notifyListeners(); }
}

class UltroidApp extends StatelessWidget{
  const UltroidApp({super.key});
  @override
  Widget build(BuildContext c){
    return ChangeNotifierProvider(create: (_) => AppState(), child: MaterialApp(
      debugShowCheckedModeBanner:false,
      theme: ThemeData.dark().copyWith(primaryColor: const Color(0xFF00E6FF)),
      home: HomePage(),
    ));
  }
}

class HomePage extends StatefulWidget{
  HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const platform = MethodChannel('ultroid.channel');
  final TextEditingController api = TextEditingController();
  final TextEditingController hash = TextEditingController();
  final TextEditingController session = TextEditingController();
  final TextEditingController redis = TextEditingController();
  final TextEditingController bot = TextEditingController();
  final TextEditingController shellCmd = TextEditingController();
  Timer? poller;

  @override
  void initState(){
    super.initState();
    poller = Timer.periodic(Duration(seconds:2), (_) => _fetchLogs());
  }

  Future<void> _fetchLogs() async {
    try {
      final res = await platform.invokeMethod('getStatusAndLogs');
      final logs = res['logs'] ?? '';
      final running = res['running'] ?? false;
      final s = Provider.of<AppState>(context, listen:false);
      s.logs = logs;
      s.running = running;
      s.notifyListeners();
    } catch(e){ /* ignore */ }
  }

  Future<void> _saveEnv() async {
    final map = {
      'API_ID': api.text,'API_HASH':hash.text,'SESSION':session.text,'REDIS_URI':redis.text,'BOT_TOKEN':bot.text
    };
    await platform.invokeMethod('saveEnv', map);
    Provider.of<AppState>(context, listen:false).append('Saved .env');
  }

  Future<void> _startBot() async {
    await platform.invokeMethod('startBot');
    Provider.of<AppState>(context, listen:false).setRunning(true);
    Provider.of<AppState>(context, listen:false).append('Start requested');
  }

  Future<void> _stopBot() async {
    await platform.invokeMethod('stopBot');
    Provider.of<AppState>(context, listen:false).setRunning(false);
    Provider.of<AppState>(context, listen:false).append('Stop requested');
  }

  Future<void> _runShell() async {
    final cmd = shellCmd.text.trim();
    if(cmd.isEmpty) return;
    Provider.of<AppState>(context, listen:false).addHistory(cmd);
    Provider.of<AppState>(context, listen:false).append('>>> $cmd');
    try {
      final out = await platform.invokeMethod('runShell', {'cmd': cmd});
      Provider.of<AppState>(context, listen:false).append(out ?? '<no output>');
    } catch(e){
      Provider.of<AppState>(context, listen:false).append('Shell error: $e');
    }
    shellCmd.clear();
  }

  Future<void> _fixDeps() async {
    Provider.of<AppState>(context, listen:false).append('Fix Dependencies: pip install -r requirements.txt');
    try {
      final out = await platform.invokeMethod('runShell', {'cmd': 'pip install -r requirements.txt'});
      Provider.of<AppState>(context, listen:false).append(out ?? '<no output>');
    } catch(e){
      Provider.of<AppState>(context, listen:false).append('Fix deps error: $e');
    }
  }

  @override
  void dispose(){ poller?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context){
    final s = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Ultroid Deployer (Offline)')),
      body: Padding(padding: EdgeInsets.all(12), child: Column(children:[
        Text('Fill .env values', style: TextStyle(fontWeight: FontWeight.bold)),
        Row(children:[
          Expanded(child: TextField(controller: api, decoration: InputDecoration(labelText:'API_ID'))),
          SizedBox(width:8),
          Expanded(child: TextField(controller: hash, decoration: InputDecoration(labelText:'API_HASH'))),
        ]),
        SizedBox(height:8),
        Row(children:[
          Expanded(child: TextField(controller: session, decoration: InputDecoration(labelText:'SESSION'))),
          SizedBox(width:8),
          Expanded(child: TextField(controller: redis, decoration: InputDecoration(labelText:'REDIS_URI'))),
        ]),
        SizedBox(height:8),
        Row(children:[
          Expanded(child: TextField(controller: bot, decoration: InputDecoration(labelText:'BOT_TOKEN'))),
          SizedBox(width:8),
          ElevatedButton(onPressed: _saveEnv, child: Text('Save .env')),
        ]),
        SizedBox(height:10),
        Row(children:[
          ElevatedButton.icon(onPressed: _startBot, icon: Icon(Icons.play_arrow), label: Text('Start Bot')),
          SizedBox(width:8),
          ElevatedButton.icon(onPressed: _stopBot, icon: Icon(Icons.stop), label: Text('Stop Bot')),
          SizedBox(width:8),
          ElevatedButton.icon(onPressed: _fixDeps, icon: Icon(Icons.auto_fix_high), label: Text('Fix Dependencies')),
          Spacer(),
          Chip(label: Text(s.running? 'RUNNING':'STOPPED')),
        ]),
        SizedBox(height:12),
        Expanded(child: Column(children:[
          Expanded(child: Container(padding: EdgeInsets.all(8), decoration: BoxDecoration(color:Colors.black87,borderRadius: BorderRadius.circular(8)),
            child: SingleChildScrollView(reverse:true, child: Text(s.logs.isEmpty? 'No logs yet.': s.logs, style: TextStyle(color: Color(0xFF00E6FF), fontFamily: 'monospace'))),
          )),
          SizedBox(height:8),
          Row(children:[
            Expanded(child: TextField(controller: shellCmd, decoration: InputDecoration(labelText:'Shell command (e.g. pip install xyz)'))),
            SizedBox(width:8),
            ElevatedButton(onPressed: _runShell, child: Text('Run')),
            SizedBox(width:8),
            PopupMenuButton<String>(onSelected: (v){ shellCmd.text=v; }, itemBuilder: (_){
              return s.history.map((h)=>PopupMenuItem(value:h,child:Text(h))).toList();
            }, icon: Icon(Icons.history))
          ])
        ]))
      ])),
    );
  }
}
