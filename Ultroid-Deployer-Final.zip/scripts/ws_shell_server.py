
#!/usr/bin/env python3
import asyncio, shlex, subprocess, os, json
from websockets import serve
HOST="127.0.0.1"; PORT=8765
async def run_cmd(ws, cmd):
    proc = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, stdin=asyncio.subprocess.PIPE)
    async def stream(pipe, typ):
        while True:
            data = await pipe.readline()
            if not data:
                break
            msg = {"type": typ, "data": data.decode(errors="replace")}
            await ws.send(json.dumps(msg))
    await asyncio.gather(stream(proc.stdout,"stdout"), stream(proc.stderr,"stderr"))
    rc = await proc.wait()
    await ws.send(json.dumps({"type":"exit","code":rc}))
async def handler(ws, path):
    await ws.send(json.dumps({"type":"ready","msg":"shell ready"}))
    async for message in ws:
        try:
            j = json.loads(message)
            if j.get("cmd"):
                cmd = j["cmd"]
                if cmd.strip().startswith("cd "):
                    path = cmd.strip()[3:].strip()
                    try:
                        os.chdir(os.path.expanduser(path))
                        await ws.send(json.dumps({"type":"stdout","data":f"cwd -> {os.getcwd()}\n"}))
                    except Exception as e:
                        await ws.send(json.dumps({"type":"stderr","data":str(e)+"\n"}))
                    continue
                await run_cmd(ws, cmd)
        except Exception as e:
            await ws.send(json.dumps({"type":"stderr","data":f"server error: {e}\n"}))
async def main():
    async with serve(handler, HOST, PORT):
        print(f"ws shell listening on ws://{HOST}:{PORT}")
        await asyncio.Future()
if __name__ == '__main__':
    asyncio.run(main())
