
#!/usr/bin/env python3
import asyncio, pickle, os, time
from asyncio import StreamReader, StreamWriter
DATA_FILE = os.path.join(os.path.dirname(__file__), 'redis_data.pickle')
DATA = {}
def load():
    global DATA
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE,'rb') as f:
                DATA = pickle.load(f)
        except: DATA={}
def save():
    try:
        with open(DATA_FILE,'wb') as f:
            pickle.dump(DATA,f)
    except: pass
def expire_cleanup():
    now=time.time()
    changed=False
    for k in list(DATA.keys()):
        val, exp = DATA[k]
        if exp is not None and exp<=now:
            del DATA[k]; changed=True
    if changed: save()
async def handle(reader: StreamReader, writer: StreamWriter):
    while True:
        line = await reader.readline()
        if not line: break
        cmd = line.decode().strip().split()
        if not cmd: continue
        cmd0 = cmd[0].upper()
        if cmd0=='PING':
            writer.write(b'+PONG\r\n')
        elif cmd0=='GET' and len(cmd)>=2:
            k=cmd[1]; expire_cleanup()
            if k in DATA:
                val, exp = DATA[k]; writer.write(b'$%d\r\n%s\r\n'%(len(str(val)), str(val).encode()))
            else:
                writer.write(b'$-1\r\n')
        elif cmd0=='SET' and len(cmd)>=3:
            k,v=cmd[1]," ".join(cmd[2:]); DATA[k]=(v,None); save(); writer.write(b'+OK\r\n')
        else:
            writer.write(b'-ERR unknown\r\n')
        await writer.drain()
    writer.close()
async def start_server():
    load()
    server = await asyncio.start_server(handle,'127.0.0.1',6379)
    async with server:
        await server.serve_forever()
if __name__=='__main__':
    try: asyncio.run(start_server())
    except KeyboardInterrupt: save()
