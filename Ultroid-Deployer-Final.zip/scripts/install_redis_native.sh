
#!/usr/bin/env bash
set -e
if command -v pkg >/dev/null 2>&1; then
  echo "Termux detected — trying pkg install redis..."
  pkg update -y || true
  pkg install -y redis || true
  if command -v redis-server >/dev/null 2>&1; then
    echo "Native redis available."
    exit 0
  fi
fi
echo "No native redis available. To use native redis, install it manually or provide binary in assets/redis/."
exit 1
