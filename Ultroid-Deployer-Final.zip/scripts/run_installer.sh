
#!/usr/bin/env bash
set -e
echo "Running installer: updating pip and installing requirements..."
if command -v pkg >/dev/null 2>&1; then
  echo "Detected Termux pkg - attempting to update packages..."
  pkg update -y || true
  pkg install -y python git || true
fi
python3 -m pip install --upgrade pip setuptools wheel || true
if [ -f requirements.txt ]; then
  python3 -m pip install -r requirements.txt || true
else
  echo "No requirements.txt found."
fi
