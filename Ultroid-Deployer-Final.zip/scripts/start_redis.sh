
#!/usr/bin/env bash
set -e
REDIS_BIN="./assets/redis/redis-server"
if [ -x "$REDIS_BIN" ]; then
  echo "Starting native redis-server..."
  "$REDIS_BIN" --daemonize yes --dir ./assets/redisdata || true
  sleep 1
  if pgrep -f redis-server >/dev/null 2>&1; then
    echo "Native redis started."
    exit 0
  fi
fi
echo "Starting Python fallback redis..."
nohup python3 scripts/redis_fallback_server.py >/dev/null 2>&1 &
sleep 1
if pgrep -f redis_fallback_server.py >/dev/null 2>&1; then
  echo "Fallback redis started."
  exit 0
fi
echo "Failed to start redis."
exit 1
