
import 'package:flutter/material.dart';

void main() => runApp(const UltroidDeployerApp());

class UltroidDeployerApp extends StatelessWidget {
  const UltroidDeployerApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ultroid Deployer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        primaryColor: const Color(0xFF00D4FF),
        scaffoldBackgroundColor: const Color(0xFF05060A),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool running = false;
  String logs = "Logs will appear here...";

  void startBot() {
    setState(() {
      running = true;
      logs = "✅ Starting Ultroid...\n" + logs;
    });
  }

  void stopBot() {
    setState(() {
      running = false;
      logs = "⛔️ Stopped by user\n" + logs;
    });
  }

  void openShell() {
    setState(() {
      logs = "💻 Shell opened (placeholder)\n" + logs;
    });
  }

  void openLogs() {
    setState(() {
      logs = "📜 Showing latest logs...\n" + logs;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ultroid Deployer'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          Card(
            color: const Color(0xFF071024),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(children: [
                const Text('Ultroid Deployer', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Wrap(spacing: 10, runSpacing: 10, children: [
                  ElevatedButton.icon(onPressed: startBot, icon: const Icon(Icons.play_arrow), label: const Text('Start')),
                  ElevatedButton.icon(onPressed: stopBot, icon: const Icon(Icons.stop), label: const Text('Stop'), style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent)),
                  ElevatedButton.icon(onPressed: openShell, icon: const Icon(Icons.terminal), label: const Text('Shell')),
                  ElevatedButton.icon(onPressed: openLogs, icon: const Icon(Icons.article), label: const Text('Logs')),
                ])
              ]),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(child: Card(
            color: const Color(0xFF02030A),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: SingleChildScrollView(child: Text(logs, style: const TextStyle(fontFamily: 'monospace'))),
            ),
          )),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [Color(0x2200D4FF), Color(0x1100A8FF)]),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0x2200D4FF)),
            ),
            child: Row(children: [
              Icon(Icons.circle, color: running ? Colors.greenAccent : Colors.redAccent, size: 12),
              const SizedBox(width:8),
              Text(running ? 'STATUS: ONLINE' : 'STATUS: OFFLINE', style: const TextStyle(fontWeight: FontWeight.bold)),
              const Spacer(),
              Text('Ultroid Deployer • ⚡ Powered by @usernamehacked0', style: const TextStyle(color: Color(0xFFBFDFFF)))
            ]),
          )
        ]),
      ),
    );
  }
}
