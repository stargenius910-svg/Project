
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const UltroidDeployerApp());

class UltroidDeployerApp extends StatelessWidget {
  const UltroidDeployerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ultroid Deployer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        primaryColor: const Color(0xFF00D4FF),
        scaffoldBackgroundColor: const Color(0xFF05060A),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool running = false;
  String logs = "Welcome to Ultroid Deployer\nFill .env and press Start.";

  final controllers = {
    "API_ID": TextEditingController(),
    "API_HASH": TextEditingController(),
    "SESSION": TextEditingController(),
    "REDIS_URI": TextEditingController(),
    "REDIS_PASSWORD": TextEditingController(),
    "BOT_TOKEN": TextEditingController(),
    "LOG_CHANNEL": TextEditingController(),
  };

  void start() {
    setState(() {
      running = true;
      logs = "✅ Starting Ultroid...\\n" + logs;
    });
  }

  void stop() {
    setState(() {
      running = false;
      logs = "⛔️ Stopped by user\\n" + logs;
    });
  }

  Future<void> openShell() async {
    // Placeholder: open Ultroid repo page or shell instructions
    final url = Uri.parse("https://github.com/TeamUltroid/Ultroid");
    if (await canLaunchUrl(url)) await launchUrl(url);
  }

  Future<void> openLogs() async {
    setState(() {
      logs = "📜 Showing latest logs...\\n" + logs;
    });
  }

  Future<void> saveEnv() async {
    setState(() {
      logs = "💾 .env saved (demo)\\n" + logs;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Image.asset('assets/icon.png', width: 36, height: 36),
          const SizedBox(width: 10),
          const Text('Ultroid Deployer', style: TextStyle(letterSpacing: 0.6))
        ]),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(children: [
          Card(
            color: const Color(0xFF071024),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(children: [
                const Text('Quick Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height:8),
                Wrap(spacing: 10, runSpacing: 10, children: [
                  ElevatedButton.icon(onPressed: start, icon: const Icon(Icons.rocket_launch), label: const Text('Start Userbot')),
                  ElevatedButton.icon(onPressed: stop, icon: const Icon(Icons.stop_circle), label: const Text('Stop Userbot'), style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent)),
                  ElevatedButton.icon(onPressed: openShell, icon: const Icon(Icons.terminal), label: const Text('Shell')),
                  ElevatedButton.icon(onPressed: openLogs, icon: const Icon(Icons.article), label: const Text('Logs')),
                ])
              ]),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(child: Card(
            color: const Color(0xFF02030A),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: SingleChildScrollView(child: Text(logs, style: const TextStyle(fontFamily: 'monospace'))),
            ),
          )),
          const SizedBox(height: 8),
          // bottom premium status bar (glass glow style)
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [Color(0x2200D4FF), Color(0x1100A8FF)]),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0x2200D4FF)),
            ),
            child: Row(children: [
              Icon(Icons.circle, color: running ? Colors.greenAccent : Colors.redAccent, size: 12),
              const SizedBox(width:8),
              Text(running ? 'STATUS: ONLINE' : 'STATUS: OFFLINE', style: const TextStyle(fontWeight: FontWeight.bold)),
              const Spacer(),
              Text('Ultroid Deployer • ⚡ Powered by @usernamehacked0', style: const TextStyle(color: Color(0xFFBFDFFF)))
            ]),
          )
        ]),
      ),
    );
  }
}
