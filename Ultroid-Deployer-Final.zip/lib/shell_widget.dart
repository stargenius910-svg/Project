
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/io.dart';

class ShellWidget extends StatefulWidget {
  final String wsUrl;
  const ShellWidget({super.key, required this.wsUrl});
  @override
  State<ShellWidget> createState() => _ShellWidgetState();
}

class _ShellWidgetState extends State<ShellWidget> {
  IOWebSocketChannel? channel;
  final TextEditingController _input = TextEditingController();
  final List<String> _lines = [];
  bool connected = false;

  @override
  void initState() {
    super.initState();
    connect();
  }

  void connect() {
    try {
      channel = IOWebSocketChannel.connect(Uri.parse(widget.wsUrl));
      channel!.stream.listen((message) {
        final m = jsonDecode(message);
        if (m['type']=='stdout' || m['type']=='stderr') {
          setState(() { _lines.add(m['data']); });
        } else if (m['type']=='ready') {
          setState(() { _lines.add('[shell ready]\\n'); connected = true; });
        } else if (m['type']=='exit') {
          setState(() { _lines.add('[proc exit ${m['code']}]\\n'); });
        }
      }, onDone: () { setState(() { _lines.add('[connection closed]'); connected=false; }); }, onError: (e){ setState(()=> _lines.add('[ws error $e]')); });
    } catch(e){
      setState(()=> _lines.add('connect error: $e'));
    }
  }

  void sendCmd(String c) {
    if (channel!=null) {
      channel!.sink.add(jsonEncode({"cmd": c}));
      setState(()=> _lines.add("> $c\n"));
    } else {
      setState(()=> _lines.add("Not connected\n"));
    }
  }

  @override
  void dispose() { channel?.sink.close(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Terminal'), backgroundColor: Colors.transparent),
      body: Column(children: [
        Expanded(child: SingleChildScrollView(padding: const EdgeInsets.all(8), child: SelectableText(_lines.join(), style: const TextStyle(fontFamily: 'monospace')))),
        Row(children: [
          Expanded(child: TextField(controller: _input, decoration: const InputDecoration(hintText: 'command'))),
          IconButton(icon: const Icon(Icons.send), onPressed: (){ sendCmd(_input.text); _input.clear(); })
        ])
      ]));
  }
}
