
Ultroid Deployer - Final ZIP (signed ready scaffold)

This ZIP contains the Flutter UI scaffold, helper scripts, requirements.txt, and an assets/ultroid placeholder.
Upload this ZIP into your GitHub repo (or extract and push contents) and add the provided workflow (separate file) to build a signed APK via GitHub Actions.
