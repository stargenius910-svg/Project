
Ultroid Deployer - Final scaffold with shell and backend scripts.
Instructions:
 - Upload Ultroid-Deployer-Final.zip to GitHub repo root or extract files into repo.
 - Add a workflow file .github/workflows/build.yml with content from .github_workflow_build.yml
 - To run backend on device: use Termux, cd to scripts/ and run: bash start_backend.sh
 - Open app, press Terminal to connect to ws://127.0.0.1:8765
