
# Ultroid Deployer (GitHub-buildable scaffold)

App name: Ultroid Deployer
Credit: ⚡ Powered by @usernamehacked0
Icon: Neon variant (placeholder)

How to use:
1. Push this repo to GitHub (branch main).
2. Go to Actions -> Build Ultroid Deployer APK -> Run workflow (or push to main). 
3. Wait for workflow to finish, then download APK from Artifacts.

Notes:
- Workflow will attempt to clone Ultroid into assets/ultroid-deployer during build time.
- If you want to include your own Ultroid code, add it under assets/ultroid-deployer/ before pushing.
- For a fully offline APK with pre-bundled binaries, additional work (bundling wheels and native libs) is required.
