
Userbot Deployer (skeleton)
By @usernamehacked0

This ZIP is a scaffold for an Android Flutter app that uses Chaquopy to run Python ultroid code inside the APK.
It DOES NOT include the full Ultroid repository (will be cloned by runner on first run).
Files included:
- lib/main.dart (Flutter UI)
- android/app/src/main/python/runner.py (Python runner)
- android/app/src/main/python/term_shell.py (shell runner)
- android/app/src/main/python/ (folder where ultroid repo will be cloned at first run)
- android/app/src/main/kotlin/.../MainActivity.kt (Kotlin glue)
- android/app/build.gradle (Chaquopy plugin example)
- pubspec.yaml, requirements.txt

How to use (quick):
1) Open this project in Android Studio (or VS Code + Flutter plugin).
2) Put the Flutter project at root; ensure android/ contains the Kotlin files and build.gradle (merge into your Android module).
3) Build using flutter build apk.
4) First run: app will clone Ultroid into app python dir (requires device internet).

IMPORTANT: This is a scaffold. Building a production APK with all dependencies (Telethon, OpenCV) will increase APK size and requires NDK and Chaquopy config.
If you want, I can produce a larger zip that includes a script to download the Ultroid repo into the python folder automatically.
