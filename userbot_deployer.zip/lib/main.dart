
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(UltroidLauncherApp());

class UltroidLauncherApp extends StatelessWidget {
  @override
  Widget build(BuildContext c) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: Color(0xFF07070A),
      primaryColor: Color(0xFF00E6FF),
    ),
    home: HomePage(),
  );
}

class HomePage extends StatefulWidget { @override _HomePageState createState() => _HomePageState(); }
class _HomePageState extends State<HomePage> {
  static const platform = MethodChannel('ultroid.channel');
  String logs = '';
  bool running = false;
  TextEditingController apiId = TextEditingController();
  TextEditingController apiHash = TextEditingController();
  TextEditingController session = TextEditingController();
  TextEditingController redisUri = TextEditingController();
  TextEditingController redisPass = TextEditingController();
  TextEditingController botToken = TextEditingController();
  TextEditingController logChannel = TextEditingController();
  TextEditingController shellCmd = TextEditingController();
  Timer? _poller;

  @override
  void initState() {
    super.initState();
    _poller = Timer.periodic(Duration(seconds:2), (_) => _fetchStatusAndLogs());
  }

  Future<void> _fetchStatusAndLogs() async {
    try {
      final res = await platform.invokeMethod('getStatusAndLogs');
      setState(() {
        running = res['running'] ?? false;
        logs = res['logs'] ?? logs;
      });
    } catch (e) { /* ignore */ }
  }

  Future<void> _saveEnv() async {
    final map = {
      "API_ID": apiId.text.trim(),
      "API_HASH": apiHash.text.trim(),
      "SESSION": session.text.trim(),
      "REDIS_URI": redisUri.text.trim(),
      "REDIS_PASSWORD": redisPass.text.trim(),
      "BOT_TOKEN": botToken.text.trim(),
      "LOG_CHANNEL": logChannel.text.trim()
    };
    await platform.invokeMethod('saveEnv', map);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Env saved")));
  }

  Future<void> _startBot() async {
    await platform.invokeMethod('startBot');
    setState(()=> running=true);
  }

  Future<void> _stopBot() async {
    await platform.invokeMethod('stopBot');
    setState(()=> running=false);
  }

  Future<void> _runShell() async {
    final out = await platform.invokeMethod('runShell', {"cmd": shellCmd.text});
    setState(()=> logs = (out ?? '') + '\n' + logs);
    shellCmd.clear();
  }

  @override
  void dispose() { _poller?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext ctx) {
    return Scaffold(
      appBar: AppBar(title: Text("Userbot Deployer — By @usernamehacked0")),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(children:[
          Row(children:[
            ElevatedButton.icon(onPressed: _startBot, icon: Icon(Icons.play_arrow), label: Text("Start"), style: ElevatedButton.styleFrom(primary: Colors.green)),
            SizedBox(width:8),
            ElevatedButton.icon(onPressed: _stopBot, icon: Icon(Icons.stop), label: Text("Stop"), style: ElevatedButton.styleFrom(primary: Colors.red)),
            SizedBox(width:8),
            ElevatedButton.icon(onPressed: _fetchStatusAndLogs, icon: Icon(Icons.refresh), label: Text("Refresh")),
            Spacer(),
            Chip(label: Text(running ? "RUNNING" : "STOPPED", style: TextStyle(color: Colors.white)), backgroundColor: running?Colors.green:Colors.grey)
          ]),
          SizedBox(height:12),
          Expanded(child: Row(children:[
            Flexible(flex:2,
              child: SingleChildScrollView(
                child: Column(children:[
                  Text("Configuration", style: TextStyle(fontWeight: FontWeight.bold)),
                  TextField(controller: apiId, decoration: InputDecoration(labelText:"API_ID")),
                  TextField(controller: apiHash, decoration: InputDecoration(labelText:"API_HASH")),
                  TextField(controller: session, decoration: InputDecoration(labelText:"SESSION")),
                  TextField(controller: redisUri, decoration: InputDecoration(labelText:"REDIS_URI")),
                  TextField(controller: redisPass, decoration: InputDecoration(labelText:"REDIS_PASSWORD")),
                  TextField(controller: botToken, decoration: InputDecoration(labelText:"BOT_TOKEN")),
                  TextField(controller: logChannel, decoration: InputDecoration(labelText:"LOG_CHANNEL")),
                  SizedBox(height:8),
                  Row(children:[
                    ElevatedButton(onPressed: _saveEnv, child: Text("Save & Apply")),
                    SizedBox(width:8),
                    ElevatedButton(onPressed: (){ apiId.clear(); apiHash.clear(); session.clear(); redisUri.clear(); redisPass.clear(); botToken.clear(); logChannel.clear(); }, child: Text("Clear"))
                  ])
                ]),
              )
            ),
            SizedBox(width:12),
            Flexible(flex:3,
              child: Column(children:[
                Text("Logs", style: TextStyle(fontWeight: FontWeight.bold)),
                Expanded(child: Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(8)),
                  child: SingleChildScrollView(reverse: true, child: Text(logs, style: TextStyle(fontFamily: 'monospace', color: Colors.lightGreenAccent))),
                )),
                SizedBox(height:8),
                TextField(controller: shellCmd, decoration: InputDecoration(labelText: "Run shell command (pip install ... )")),
                SizedBox(height:6),
                Row(children:[
                  ElevatedButton(onPressed: _runShell, child: Text("Run")),
                  SizedBox(width:8),
                  ElevatedButton(onPressed: (){ setState(()=> logs=''); }, child: Text("Clear Logs"))
                ])
              ])
            )
          ]))
        ]),
      ),
    );
  }
}
