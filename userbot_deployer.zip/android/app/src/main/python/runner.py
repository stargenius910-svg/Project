
import threading, subprocess, os, time, shutil, sys

APP_DIR = os.path.dirname(__file__)
LOG_PATH = os.path.join(APP_DIR, "ultroid.log")
ULTROID_DIR = os.path.join(APP_DIR, "ultroid")  # repo will be cloned here if absent
_proc = None
_lock = threading.Lock()

def _write_log(s):
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(f"{s}\n")
    print(s, flush=True)

def ensure_ultroid():
    if not os.path.exists(ULTROID_DIR):
        _write_log("[runner] Ultroid repo not found, cloning...")
        try:
            # try to use git if available
            subprocess.run(["git","clone","https://github.com/TeamUltroid/Ultroid.git", ULTROID_DIR], check=True)
            _write_log("[runner] Ultroid cloned successfully")
        except Exception as e:
            _write_log("[runner] Error cloning Ultroid: " + str(e))
            _write_log("[runner] Please ensure device has internet and git installed.")

def start_bot_async():
    threading.Thread(target=start_bot, daemon=True).start()

def start_bot():
    global _proc
    with _lock:
        if _proc:
            _write_log("[runner] already running")
            return
        ensure_ultroid()
        envpath = os.path.join(APP_DIR, ".env")
        env = {}
        if os.path.exists(envpath):
            for l in open(envpath,'r',encoding='utf-8').read().splitlines():
                if '=' in l:
                    k,v = l.split('=',1); env[k]=v
        ultroid_path = ULTROID_DIR
        cmd = [sys.executable, "-m", "pyUltroid"]
        _write_log("[runner] starting pyUltroid...")
        try:
            _proc = subprocess.Popen(cmd, cwd=ultroid_path, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env={**os.environ, **env}, text=True, bufsize=1)
        except Exception as e:
            _write_log("[runner] start failed: " + str(e))
            _proc = None
            return
        for line in _proc.stdout:
            _write_log(line.rstrip())
        _proc.wait()
        _write_log(f"[runner] process exited {_proc.returncode}")
        _proc = None

def stop_bot():
    global _proc
    with _lock:
        if _proc:
            try:
                _proc.terminate()
                _write_log("[runner] terminate sent")
            except Exception as e:
                _write_log("[runner] stop error: "+str(e))
            _proc = None
        else:
            _write_log("[runner] not running")

def is_running():
    return _proc is not None

def read_logs():
    if os.path.exists(LOG_PATH):
        return open(LOG_PATH,'r',encoding='utf-8').read()[-12000:]
    return ""
