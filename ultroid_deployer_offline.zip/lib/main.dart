
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import 'package:flutter/services.dart';

void main() => runApp(const UltroidApp());

class AppState extends ChangeNotifier {
  String logs = '';
  bool running = false;
  void append(String s){ logs = '${DateTime.now().toIso8601String()} $s\n' + logs; notifyListeners(); }
  void setRunning(bool v){ running=v; notifyListeners(); }
  void clear(){ logs=''; notifyListeners(); }
}

class UltroidApp extends StatelessWidget{
  const UltroidApp({super.key});
  @override
  Widget build(BuildContext c){
    return ChangeNotifierProvider(create: (_) => AppState(), child: MaterialApp(
      debugShowCheckedModeBanner:false,
      theme: ThemeData.dark().copyWith(primaryColor: Color(0xFF00E6FF)),
      home: HomePage(),
    ));
  }
}

class HomePage extends StatelessWidget{
  HomePage({super.key});
  static const platform = MethodChannel('ultroid.channel');
  final TextEditingController api = TextEditingController();
  final TextEditingController hash = TextEditingController();
  final TextEditingController session = TextEditingController();
  final TextEditingController redis = TextEditingController();
  final TextEditingController bot = TextEditingController();

  @override
  Widget build(BuildContext context){
    final s = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Ultroid Deployer (Offline)')),
      body: Padding(padding: EdgeInsets.all(12), child: Column(children:[
        Text('Fill .env values', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: api, decoration: InputDecoration(labelText:'API_ID')),
        TextField(controller: hash, decoration: InputDecoration(labelText:'API_HASH')),
        TextField(controller: session, decoration: InputDecoration(labelText:'SESSION')),
        TextField(controller: redis, decoration: InputDecoration(labelText:'REDIS_URI')),
        TextField(controller: bot, decoration: InputDecoration(labelText:'BOT_TOKEN')),
        SizedBox(height:8),
        Row(children:[
          ElevatedButton(onPressed: () async {
            final map = {
              'API_ID': api.text,'API_HASH':hash.text,'SESSION':session.text,'REDIS_URI':redis.text,'BOT_TOKEN':bot.text
            };
            try{ await platform.invokeMethod('saveEnv', map); s.append('Saved .env'); }catch(e){ s.append('saveEnv failed: $e'); }
          }, child: Text('Save .env')),
          SizedBox(width:8),
          ElevatedButton(onPressed: () async {
            try{ await platform.invokeMethod('startBot'); s.setRunning(true); s.append('Start command sent'); }catch(e){ s.append('startBot failed: $e'); }
          }, child: Text('Start Bot')),
          SizedBox(width:8),
          ElevatedButton(onPressed: () async {
            try{ await platform.invokeMethod('stopBot'); s.setRunning(false); s.append('Stop command sent'); }catch(e){ s.append('stopBot failed: $e'); }
          }, child: Text('Stop Bot')),
        ]),
        SizedBox(height:12),
        Expanded(child: Container(padding: EdgeInsets.all(8), decoration: BoxDecoration(color:Colors.black87,borderRadius: BorderRadius.circular(8)),
          child: Consumer<AppState>(builder:(c,st,_)=>SingleChildScrollView(reverse:true, child: Text(st.logs.isEmpty?'No logs yet.':st.logs, style: TextStyle(color: Color(0xFF00E6FF), fontFamily: 'monospace')))),
        ))
      ])),
    );
  }
}
