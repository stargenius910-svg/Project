
Ultroid Deployer (Offline-ready scaffold)
========================================
This scaffold creates an Android app project (Flutter UI + Chaquopy python bridge).
IMPORTANT: To make the app fully offline (no GitHub), you MUST copy your full Ultroid repository into:
  android/app/src/main/python/ultroid/

Then build the APK (Android Studio + Chaquopy) or use other methods described earlier.

Included files:
- lib/main.dart (Flutter UI)
- android/.../MainActivity.kt (Chaquopy bridge)
- android/.../python/runner.py (starts pyUltroid from bundled ultroid folder)
- android/.../python/ultroid/README.txt (placeholder)
- build.sh helper for desktop builds
