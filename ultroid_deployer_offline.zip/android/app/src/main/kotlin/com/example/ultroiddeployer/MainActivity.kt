
package com.example.ultroiddeployer

import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

class MainActivity: FlutterActivity() {
  private val CHANNEL = "ultroid.channel"
  override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)
    if (!Python.isStarted()) {
      Python.start(AndroidPlatform(this))
    }
    val py = Python.getInstance()
    MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
      when(call.method) {
        "saveEnv" -> {
          val map = call.arguments as Map<String, String>
          val envFile = File(applicationContext.filesDir, ".env")
          val sb = StringBuilder()
          map.forEach { (k,v) -> sb.append("$k=$v\n") }
          envFile.writeText(sb.toString())
          result.success(null)
        }
        "startBot" -> {
          val pyObj = py.getModule("runner")
          pyObj.callAttr("start_bot_async")
          result.success(null)
        }
        "stopBot" -> {
          val pyObj = py.getModule("runner")
          pyObj.callAttr("stop_bot")
          result.success(null)
        }
        else -> result.notImplemented()
      }
    }
  }
}
