
import subprocess, shlex
def run_shell_sync(cmd):
    try:
        p = subprocess.Popen(shlex.split(cmd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        out = p.communicate()[0]
        return out
    except Exception as e:
        return str(e)
