
#!/usr/bin/env bash
echo "This helper runs a desktop build if you have Flutter installed."
if command -v flutter >/dev/null 2>&1; then
  flutter pub get
  flutter build apk --release
  echo "APK: build/app/outputs/flutter-apk/app-release.apk"
else
  echo "Install Flutter on desktop to run build, or open this project in Android Studio."
fi
