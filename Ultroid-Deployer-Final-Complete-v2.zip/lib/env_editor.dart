
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class EnvEditor extends StatefulWidget {
  const EnvEditor({super.key});
  @override
  State<EnvEditor> createState() => _EnvEditorState();
}

class _EnvEditorState extends State<EnvEditor> {
  final Map<String, TextEditingController> ctrls = {
    'API_ID': TextEditingController(),
    'API_HASH': TextEditingController(),
    'SESSION': TextEditingController(),
    'REDIS_URI': TextEditingController(),
    'REDIS_PASSWORD': TextEditingController(),
    'BOT_TOKEN': TextEditingController(),
    'LOG_CHANNEL': TextEditingController(),
  };
  @override
  void dispose() { for (var c in ctrls.values) c.dispose(); super.dispose(); }
  Future<void> _save() async {
    final dir = await getApplicationDocumentsDirectory();
    final f = File('${dir.path}/.env');
    final lines = ctrls.entries.map((e) => '${e.key}=${e.value.text}').join('\n');
    await f.writeAsString(lines);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved .env')));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Config')), body: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
      Expanded(child: ListView(children: ctrls.entries.map((e) => Padding(padding: const EdgeInsets.symmetric(vertical:6), child: TextField(controller: e.value, decoration: InputDecoration(labelText: e.key)))) .toList())),
      ElevatedButton(onPressed: _save, child: const Text('Save & Continue'))
    ])));
  }
}
