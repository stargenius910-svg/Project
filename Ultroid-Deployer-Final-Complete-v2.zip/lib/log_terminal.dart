
import 'package:flutter/material.dart';
class LogTerminal extends StatefulWidget {
  const LogTerminal({super.key});
  @override
  State<LogTerminal> createState() => _LogTerminalState();
}
class _LogTerminalState extends State<LogTerminal> {
  final List<String> _lines = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Logs')), body: Column(children: [
      Expanded(child: SingleChildScrollView(padding: const EdgeInsets.all(8), child: SelectableText(_lines.join('\n'), style: const TextStyle(fontFamily: 'monospace')))),
      Row(children: [TextButton(onPressed: (){ setState(()=> _lines.add('[log] sample line')); }, child: const Text('Add sample')), TextButton(onPressed: (){ setState(()=> _lines.clear()); }, child: const Text('Clear'))])
    ]));
  }
}
