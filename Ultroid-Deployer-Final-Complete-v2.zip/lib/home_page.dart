
import 'package:flutter/material.dart';
import 'env_editor.dart';
import 'shell_widget.dart';
import 'log_terminal.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool running = false;
  String status = 'OFFLINE';
  String uptime = '0s';

  @override
  void initState() {
    super.initState();
    _loadStatus();
  }

  Future<void> _loadStatus() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      running = p.getBool('running') ?? false;
      status = running ? 'ONLINE' : 'OFFLINE';
    });
  }

  Future<void> _setRunning(bool val) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('running', val);
    setState(() {
      running = val;
      status = val ? 'ONLINE' : 'OFFLINE';
    });
  }

  void _start() async {
    await _setRunning(true);
  }

  void _stop() async {
    await _setRunning(false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ultroid Deployer'), centerTitle: true, backgroundColor: Colors.transparent, elevation: 0),
      body: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
        Card(color: const Color(0xFF071024), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
            const Text('Ultroid Deployer', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height:8),
            Wrap(spacing:10, children:[
              ElevatedButton.icon(onPressed: _start, icon: const Icon(Icons.play_arrow), label: const Text('Start')),
              ElevatedButton.icon(onPressed: _stop, icon: const Icon(Icons.stop), label: const Text('Stop'), style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent)),
              ElevatedButton.icon(onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (_) => const ShellWidget(wsUrl: 'ws://127.0.0.1:8765'))); }, icon: const Icon(Icons.terminal), label: const Text('Terminal')),
              ElevatedButton.icon(onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (_) => const LogTerminal())); }, icon: const Icon(Icons.article), label: const Text('Logs')),
              ElevatedButton.icon(onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (_) => const EnvEditor())); }, icon: const Icon(Icons.settings), label: const Text('Config')),
            ])
          ]))),
        const SizedBox(height:12),
        Expanded(child: Card(color: const Color(0xFF02030A), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(padding: const EdgeInsets.all(12), child: SingleChildScrollView(child: Text('Status: $status\nUptime: $uptime\n\nLogs appear in Terminal.', style: const TextStyle(fontFamily: 'monospace')))))),
        const SizedBox(height:8),
        Container(padding: const EdgeInsets.symmetric(vertical:10,horizontal:12),
          decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0x2200D4FF), Color(0x1100A8FF)]), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0x2200D4FF))),
          child: Row(children: [Icon(Icons.circle, color: running?Colors.greenAccent:Colors.redAccent,size:12), const SizedBox(width:8), Text(running?'STATUS: ONLINE':'STATUS: OFFLINE', style: const TextStyle(fontWeight: FontWeight.bold)), const Spacer(), const Text('Created by @StarGenius ✨', style: TextStyle(color: Color(0xFFBFDFFF))) ]))
      ])),
    );
  }
}
