
import 'package:flutter/material.dart';
import 'home_page.dart';
void main() => runApp(const UltroidDeployerApp());
class UltroidDeployerApp extends StatelessWidget {
  const UltroidDeployerApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ultroid Deployer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        primaryColor: const Color(0xFF00D4FF),
        scaffoldBackgroundColor: const Color(0xFF05060A),
      ),
      home: const HomePage(),
    );
  }
}
