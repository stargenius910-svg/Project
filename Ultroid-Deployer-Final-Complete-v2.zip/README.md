
Ultroid Deployer - Final buildable scaffold.
Includes Flutter UI (Start/Stop/Terminal/Config), backend scripts for Termux (ws shell + redis fallback), ultroid placeholder, and GitHub workflow instructions.

Instructions:
1. Upload this ZIP to your GitHub repo root as Ultroid-Deployer-Final.zip (or extract files into the repo root).
2. Add the workflow file .github/workflows/build.yml (provided) to your repo.
3. Run the GitHub Action to build the APK, or build locally with flutter.
4. To run backend on device, use Termux and run: cd scripts && bash start_backend.sh
