
#!/usr/bin/env bash
pkill -f ws_shell_server.py || true
pkill -f redis_fallback_server.py || true
echo "backend stopped"
