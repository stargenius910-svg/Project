
#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m pip install --upgrade pip setuptools wheel || true
if [ -f ../requirements.txt ]; then python3 -m pip install -r ../requirements.txt || true; fi
if [ -f ../ultroid/requirements.txt ]; then python3 -m pip install -r ../ultroid/requirements.txt || true; fi
nohup python3 redis_fallback_server.py >/tmp/redis_fallback.log 2>&1 &
nohup python3 ws_shell_server.py >/tmp/ws_shell.log 2>&1 &
echo "backend started"
